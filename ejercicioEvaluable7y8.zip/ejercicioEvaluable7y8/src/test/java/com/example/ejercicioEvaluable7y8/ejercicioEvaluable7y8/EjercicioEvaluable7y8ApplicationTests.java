package com.example.ejercicioEvaluable7y8.ejercicioEvaluable7y8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioEvaluable7y8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
